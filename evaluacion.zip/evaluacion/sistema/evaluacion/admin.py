from django.contrib import admin
from .models import tareas

admin.site.register(tareas)

# Register your models here.
